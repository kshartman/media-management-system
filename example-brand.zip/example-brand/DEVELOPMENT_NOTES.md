# Example Brand - Development Notes

**⚠️ PRIVATE**: This file is part of the private example-brand repository and should NOT be committed to the public repository.

## Project-Specific Configuration

### Domain
- **Production**: media.example.com
- **Dev Server**: Same domain, different environment

### Dev Server Details
- **SSH**: `ssh yourserver`
- **Project Path**: `~/projects/media-management-system`
- **Frontend Port**: 5000 (Docker) → 3000 (internal)
- **Backend Port**: 5001 (Docker) → 5001 (internal)

### Docker Deployment Commands
```bash
# Full deployment sequence
ssh yourserver "cd ~/projects/media-management-system && git pull origin master"
ssh yourserver "cd ~/projects/media-management-system && docker compose down"
ssh yourserver "cd ~/projects/media-management-system && docker compose up --build -d"
ssh yourserver "cd ~/projects/media-management-system && docker compose ps"
```

## AWS S3 Configuration

### Bucket Details
- **Bucket Name**: `your-bucket-name`
- **Region**: `us-east-1`
- **Folder**: `media/`

### S3 URL Format
- ✅ **Correct Format**: `https://your-bucket-name.s3.us-east-1.amazonaws.com/media/...`
- ❌ **Old Format**: `https://your-bucket-name.s3.amazonaws.com/...` (causes 403 errors)

### CORS Configuration
Applied to `your-bucket-name` bucket:
```json
[
  {
    "AllowedOrigins": ["*"],
    "AllowedMethods": ["GET", "HEAD"],
    "AllowedHeaders": ["*"],
    "ExposeHeaders": [
      "Content-Length",
      "Content-Range",
      "Accept-Ranges",
      "Content-Type"
    ],
    "MaxAgeSeconds": 3600
  }
]
```

### Bucket Policy
```json
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": "*",
      "Action": "s3:GetObject",
      "Resource": "arn:aws:s3:::your-bucket-name/*"
    }
  ]
}
```

## MongoDB Configuration

### Connection Details
- **Connection String**: Stored in encrypted `.env` files
- **Database Name**: `media-management`
- **Authentication**: SCRAM-SHA-256

## Email Configuration

### SendGrid
- **From Email**: Configure in encrypted `.env` files
- **API Key**: Stored in encrypted environment files

## Nginx Configuration

### Server Block
```nginx
server {
    listen 443 ssl http2;
    server_name media.example.com;

    ssl_certificate /etc/ssl/certs/example-cert.pem;
    ssl_certificate_key /etc/ssl/private/example-key.pem;

    # Frontend
    location / {
        proxy_pass http://frontend:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }

    # Backend API
    location /api/ {
        proxy_pass http://backend:5001/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto https;
    }
}

# Redirect HTTP to HTTPS
server {
    listen 80;
    server_name media.example.com;
    return 301 https://$server_name$request_uri;
}
```

## Troubleshooting Notes

### S3 URL Migration
If Safari video streaming fails with 403 errors:
1. Check that URLs use regional format (`s3.us-east-1.amazonaws.com`)
2. Run migration script if needed: `node server/scripts/migrate-s3-urls.js`

### Common Issues
- **Video streaming fails**: Check S3 CORS configuration
- **Download issues**: Verify signed URL generation in backend
- **Safari-specific issues**: Check that regional S3 URLs are being used

## Security Notes

### Environment Files
All sensitive credentials are stored in encrypted `.env` files:
- `env/.env.production.gpg` - Production environment
- `env/.env.local.gpg` - Local development
- `env/.env.docker.gpg` - Docker deployment

### Decryption
```bash
# Decrypt for deployment
gpg -d env/.env.production.gpg > env/.env.production

# Use in deploy.sh script
```

### Encryption (when updating)
```bash
# Encrypt updated file
gpg -c env/.env.production -o env/.env.production.gpg

# Commit only the .gpg file
git add env/.env.production.gpg
git commit -m "Update production environment configuration"
```

## Deployment Checklist

### Before Deploying
- [ ] Pull latest changes from main repo
- [ ] Run deploy.sh to link brand configuration
- [ ] Verify environment files are decrypted (if needed)
- [ ] Test build locally if making significant changes

### Deployment Steps
1. SSH to your server
2. Navigate to project directory
3. Pull latest code
4. Run docker compose down
5. Run docker compose up --build -d
6. Verify containers are running
7. Check logs for errors

### After Deployment
- [ ] Verify frontend is accessible at https://media.example.com
- [ ] Test login functionality
- [ ] Upload a test media file
- [ ] Verify download functionality
- [ ] Check video streaming (especially Safari)
- [ ] Monitor logs for errors

## Monitoring

### Health Checks
- Frontend: `https://media.example.com/api/health`
- Backend: Direct container health check

### Log Access
```bash
# View all logs
ssh yourserver "cd ~/projects/media-management-system && docker compose logs -f"

# View backend logs only
ssh yourserver "cd ~/projects/media-management-system && docker compose logs -f backend"

# View frontend logs only
ssh yourserver "cd ~/projects/media-management-system && docker compose logs -f frontend"
```

## Development Workflow

### Local Development with Brand
```bash
# Run deployment script
cd example-brand
./deploy.sh

# Choose option 2 (Local Development)
# This decrypts and copies .env.local

# Start development servers
cd ..
npm run dev  # Frontend

cd server
npm run dev  # Backend
```

### Making Changes
1. Make code changes in main repository
2. Test locally with your brand configuration
3. Commit to main repository
4. Deploy to server using commands above

## Notes

When configuring your brand:
- Update S3 bucket name throughout
- Set your domain name
- Configure your external links
- Encrypt your environment files with GPG
- Keep this folder in a separate private repository
