# Environment Files

This folder contains example environment configuration files for different deployment scenarios.

## Example Files

- **`.env.docker.example`** - Production Docker deployment configuration
- **`.env.local.example`** - Local frontend development configuration
- **`.env.example`** - Backend server configuration

## Setup Instructions

### 1. Create Your Environment Files

Copy the example files and fill in your actual values:

```bash
cp .env.docker.example .env.docker
cp .env.local.example .env.local
cp .env.example .env

# Edit each file with your actual credentials
nano .env.docker
nano .env.local
nano .env
```

### 2. Encrypt with GPG

For security, encrypt your environment files with GPG before committing to your private repository:

```bash
# Encrypt each file
gpg -c .env.docker -o .env.docker.gpg
gpg -c .env.local -o .env.local.gpg
gpg -c .env -o .env.gpg

# Delete the unencrypted versions
rm .env.docker .env.local .env
```

### 3. Commit Only Encrypted Files

```bash
git add *.gpg
git commit -m "Add encrypted environment files"
```

**IMPORTANT**: Never commit the unencrypted `.env` files to git. Only commit the `.gpg` encrypted versions.

## Decryption During Deployment

The `deploy.sh` script will automatically decrypt the appropriate environment file based on your deployment choice:

1. **Production (Docker)** - Decrypts `.env.docker.gpg` to project root as `.env`
2. **Local Development** - Decrypts `.env.local.gpg` to project root as `.env.local`
3. **Server/Backend** - Decrypts `.env.gpg` to `server/.env`

You'll be prompted for your GPG passphrase during deployment.

## Required Environment Variables

### All Environments

- `NEXT_PUBLIC_BRAND_CONFIG` - Your brand identifier (e.g., "example")
- `MONGODB_URI` - MongoDB connection string
- `JWT_SECRET` - Secret key for JWT tokens (min 32 characters)
- `AWS_REGION` - AWS region for S3
- `AWS_ACCESS_KEY_ID` - AWS access key
- `AWS_SECRET_ACCESS_KEY` - AWS secret key
- `S3_BUCKET` - S3 bucket name
- `SENDGRID_API_KEY` - SendGrid API key
- `SENDGRID_FROM_EMAIL` - Email sender address

### Docker Production

- `FRONTEND_URL` - Production frontend URL (e.g., https://media.example.com)
- `BACKEND_URL` - Backend URL for Docker network (e.g., http://backend:5001)
- `ALLOWED_ORIGINS` - Comma-separated list of allowed CORS origins
- `PORT` - Backend port (default: 5001)
- `NODE_ENV` - Set to "production"

### Local Development

- `BACKEND_URL` - Local backend URL (e.g., http://localhost:3001)
- `FRONTEND_URL` - Local frontend URL (e.g., http://localhost:3000)
- `ALLOWED_ORIGINS` - Localhost origins for CORS

## Security Best Practices

1. **Use Strong Secrets**: Generate long random strings for JWT_SECRET and SESSION_SECRET
2. **Encrypt Everything**: Always encrypt environment files with GPG
3. **Different Secrets Per Environment**: Use different secrets for dev/staging/production
4. **Restrict AWS Permissions**: Use least-privilege IAM policies for S3 access
5. **Rotate Credentials**: Regularly rotate API keys and secrets
6. **Private Repository**: Keep this brand folder in a separate private repository

## TroublSecure Secrets

```bash
# Generate a secure random secret (32+ characters)
openssl rand -base64 32

# Or use Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```
