#!/bin/bash
#
# Example Brand Deployment Script
# Copies brand-specific files into the main Media Management System
#
# IMPORTANT: Uses cp instead of symlinks because Docker builds don't follow
# symlinks outside the build context. Symlinks will cause "module not found" errors.
#

set -e  # Exit on error

# Get the directory where this script is located
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

echo "=================================="
echo "Example Brand Deployment"
echo "=================================="
echo ""
echo "Script directory: $SCRIPT_DIR"
echo "Project root: $PROJECT_ROOT"
echo ""

# Function to copy file with confirmation
copy_file() {
    local source=$1
    local target=$2

    # Remove existing file/symlink if it exists
    if [ -e "$target" ] || [ -L "$target" ]; then
        echo "Removing existing: $target"
        rm -f "$target"
    fi

    # Copy file (NOT symlink - Docker builds don't follow external symlinks)
    echo "Copying: $(basename $target)"
    cp "$source" "$target"
}

# Copy brand assets
echo "Step 1: Copying brand assets..."
copy_file "$SCRIPT_DIR/assets/your-logo.png" "$PROJECT_ROOT/public/your-logo.png"
echo ""

# Copy brand configuration
echo "Step 2: Copying brand configuration..."
copy_file "$SCRIPT_DIR/config/brand.config.example.ts" "$PROJECT_ROOT/src/config/brand.config.example.ts"
echo ""

# Decrypt and deploy environment files
echo "Step 3: Deploying environment files..."
echo ""
echo "Choose deployment environment:"
echo "  1) Production (Docker)"
echo "  2) Local Development"
echo "  3) Server/Backend only"
echo "  4) All environments"
echo "  5) Skip environment files"
read -p "Enter choice [1-5]: " env_choice

case $env_choice in
    1)
        echo "Decrypting production environment..."
        gpg -d "$SCRIPT_DIR/env/.env.docker.gpg" > "$PROJECT_ROOT/.env"
        echo "Created: .env"
        ;;
    2)
        echo "Decrypting local development environment..."
        gpg -d "$SCRIPT_DIR/env/.env.local.gpg" > "$PROJECT_ROOT/.env.local"
        echo "Created: .env.local"
        ;;
    3)
        echo "Decrypting server environment..."
        gpg -d "$SCRIPT_DIR/env/.env.gpg" > "$PROJECT_ROOT/server/.env"
        echo "Created: server/.env"
        ;;
    4)
        echo "Decrypting all environments..."
        gpg -d "$SCRIPT_DIR/env/.env.docker.gpg" > "$PROJECT_ROOT/.env"
        gpg -d "$SCRIPT_DIR/env/.env.local.gpg" > "$PROJECT_ROOT/.env.local"
        gpg -d "$SCRIPT_DIR/env/.env.gpg" > "$PROJECT_ROOT/server/.env"
        echo "Created: .env, .env.local, server/.env"
        ;;
    5)
        echo "Skipping environment files"
        ;;
    *)
        echo "Invalid choice. Skipping environment files."
        ;;
esac

echo ""
echo "=================================="
echo "Deployment Complete!"
echo "=================================="
echo ""
echo "Next steps:"
echo "  1. Verify brand configuration: NEXT_PUBLIC_BRAND_CONFIG=example"
echo "  2. Build the application: npm run build"
echo "  3. Start the application: npm start"
echo ""
