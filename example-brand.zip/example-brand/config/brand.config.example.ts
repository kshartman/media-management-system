// Example brand configuration
// Copy this file and customize for your brand

import type { BrandConfig } from './types';

const brandConfig: BrandConfig = {
  // Company Information
  companyName: 'Your Company Name',
  appTitle: 'Your App Title',
  appDescription: 'A system for managing and browsing digital media assets',

  // Visual Assets
  logoPath: '/your-logo.png',
  faviconPath: '/favicon.ico',

  // Theme Colors
  theme: {
    headerBackground: '#f0f0f0', // Light gray - used in header
    primaryColor: '#3b82f6',     // Blue - primary brand color
    adminColor: '#9333ea',       // Purple - admin role color
    editorColor: '#3b82f6',      // Blue - editor role color
  },

  // External Links (set to null to hide menu items)
  externalLinks: {
    portal: {
      label: 'Your Portal',
      url: 'https://portal.example.com'
    },
    training: {
      label: 'Training',
      url: 'https://example.com/training'
    }
  },

  // Domain Configuration (referenced in .env files)
  domain: 'media.example.com',

  // Trash Configuration
  trash: {
    retentionDays: 30 // Keep deleted items for 30 days before permanent deletion
  },
};

export default brandConfig;
