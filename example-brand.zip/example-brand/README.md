# Example Brand Configuration

This is a **redacted example** of how the white-label brand system works for the Media Management System.

## What This Shows

This folder demonstrates the brand overlay pattern where:

1. **Separate Repository**: Brand-specific files live in a private repo (not committed to main codebase)
2. **Deploy Script**: `deploy.sh` copies files into the main project
3. **Environment Files**: Encrypted `.gpg` files store secrets (shown as examples here)
4. **Brand Config**: TypeScript file defines branding, domain, S3 bucket, etc.
5. **Assets**: Logo files and other brand-specific assets

## Structure

```
example-brand/
├── assets/              # Brand logos and images
├── aws/                 # S3 bucket policies
├── config/              # Brand configuration TypeScript files
├── env/                 # Encrypted environment files (.gpg)
├── deploy.sh            # Script to deploy brand files
├── DEVELOPMENT_NOTES.md # Brand-specific deployment guide
└── README.md            # This file
```

## How to Use This

### 1. Create Your Brand Folder

```bash
# In your project directory
mkdir -p your-client-brand/{assets,config,aws,env}
cd your-client-brand
git init
```

### 2. Customize Brand Config

Copy and edit `config/brand.config.example.ts`:

```bash
cp config/brand.config.example.ts config/brand.config.yourclient.ts
# Edit with your company name, domain, S3 bucket, colors, etc.
```

### 3. Add Your Logo

```bash
cp /path/to/your-logo.png assets/your-logo.png
```

### 4. Create Environment Files

```bash
# Copy example and fill in your secrets
cp env/.env.docker.example env/.env.docker
# Edit with real MongoDB URI, SendGrid keys, AWS credentials, etc.

# Encrypt for security
gpg -c env/.env.docker -o env/.env.docker.gpg

# Delete unencrypted file
rm env/.env.docker
```

### 5. Update Deploy Script

Edit `deploy.sh` to reference your brand name and files.

### 6. Deploy Your Brand

```bash
./deploy.sh
# Choose option 1 for Production (Docker)
# or option 2 for Local Development
```

## Important Notes

- **Encrypted Files**: The `.gpg` files in this example are encrypted and safe to share as examples. Your actual files will need your GPG passphrase to decrypt.

- **S3 Bucket Configuration**: Notice how the S3 bucket hostname is configured in the brand config file, not in next.config.ts. This keeps all brand-specific config together.

- **Copy vs Symlink**: The deploy script uses `cp` not `ln -sf` because Docker builds don't follow symlinks outside the build context.

- **Keep Private**: Your actual brand folder should be in a **separate private repository**, never committed to the main public repo.

## See Also

- **BRAND_OVERLAY_GUIDE.md** - Complete guide to the brand overlay system
- **WHITE_LABEL_GUIDE.md** - White-labeling guide for clients
- **acme-brand/** - Another example in the main repository

## Questions?

Check the main repository documentation or open an issue.

---

**Note**: All sensitive values in this example have been redacted. This is purely for demonstration purposes.
