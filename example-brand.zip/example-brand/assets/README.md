# Brand Assets

Place your brand's logo file here.

## Logo Requirements

- **Filename**: `your-logo.png` (or update `deploy.sh` to match your filename)
- **Format**: PNG (recommended) or JPG
- **Recommended size**: 200x50 pixels (adjust based on your needs)
- **Location**: This file will be copied to `public/your-logo.png` in the main project

## Example

```bash
# Copy your logo to this folder
cp /path/to/your-company-logo.png assets/your-logo.png

# Update the brand config to reference it
# In config/brand.config.example.ts:
logoPath: '/your-logo.png',
```

## Deployment

The `deploy.sh` script will automatically copy this logo to the correct location in the public folder.
