#!/bin/bash
#
# Example Remote Deployment Script
# Deploys example brand to production server with Docker
#
# Usage: ./deploy-remote.sh [branch_name] [-y]
# Default branch: main
# -y flag: Skip confirmation prompts
#

set -e  # Exit on error

# Configuration
REMOTE_HOST="yourserver"
PROJECT_DIR="~/projects/media-management-system"
BRANCH="${1:-main}"  # Use first argument or default to 'main'
AUTO_CONFIRM=false

# Check for -y flag in arguments
for arg in "$@"; do
    if [[ "$arg" == "-y" ]]; then
        AUTO_CONFIRM=true
    fi
done

echo "=================================="
echo "Example Remote Deployment"
echo "=================================="
echo ""
echo "Remote host: $REMOTE_HOST"
echo "Project directory: $PROJECT_DIR"
echo "Branch: $BRANCH"
echo ""

# Step 1: Pull latest code
echo "Step 1: Pulling latest code from branch '$BRANCH'..."
ssh $REMOTE_HOST "cd $PROJECT_DIR && git fetch origin && git checkout $BRANCH && git pull origin $BRANCH"
echo "✓ Code updated"
echo ""

# Step 2: Copy brand configuration
echo "Step 2: Copying brand configuration..."
echo "NOTE: Using cp instead of ln -sf because Docker builds don't follow external symlinks"
ssh $REMOTE_HOST "cd $PROJECT_DIR && cp example-brand/config/brand.config.example.ts src/config/brand.config.example.ts"
ssh $REMOTE_HOST "cd $PROJECT_DIR && cp example-brand/assets/your-logo.png public/your-logo.png"
echo "✓ Brand files copied"
echo ""

# Step 3: Docker deployment
echo "Step 3: Deploying with Docker..."
echo "This will:"
echo "  - Stop existing containers"
echo "  - Rebuild images with latest code"
echo "  - Start containers in detached mode"
echo ""

if [[ "$AUTO_CONFIRM" == false ]]; then
    read -p "Continue with Docker deployment? (y/n): " confirm
    if [[ $confirm != "y" && $confirm != "Y" ]]; then
        echo "Deployment cancelled."
        exit 0
    fi
else
    echo "Auto-confirming deployment (use -y flag)..."
fi

ssh $REMOTE_HOST "cd $PROJECT_DIR && docker compose down && docker compose up --build -d"
echo "✓ Docker deployment complete"
echo ""

# Step 4: Verify deployment
echo "Step 4: Verifying deployment..."
ssh $REMOTE_HOST "cd $PROJECT_DIR && docker compose ps"
echo ""

echo "=================================="
echo "Deployment Complete!"
echo "=================================="
echo ""
echo "Branch deployed: $BRANCH"
echo "Next steps:"
echo "  1. Check container logs: ssh $REMOTE_HOST 'cd $PROJECT_DIR && docker compose logs -f'"
echo "  2. Test file uploads in production"
echo "  3. Monitor for any errors"
echo ""
